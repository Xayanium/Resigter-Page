<template>
  <div style="width: 100vw;height: 100vh;overflow: hidden;display: flex;">
    <div style="flex: 1;background-color: #535bf2">

      <!--      <img :src="imgUrl" style="width: 100%;height: 100%" alt="">-->
      <el-image :src="imgUrl" style="width: 100%;height: 100%" fit="cover"></el-image>
    </div>

    <div class="welcome-foot">
      <div style="font-size: 2.3rem; font-weight: bold">Welcome To Our Website</div>
      <div style="margin-top: 1.3rem">－ サクラノ詩 －櫻の森の上を舞う －</div>
      <div style="margin-top: 1.3rem">－ サクラノ刻 －櫻の森の下を歩む －</div>
    </div>

    <div style="width: 30rem;background-color: #fefefe; z-index: 1">

      <router-view v-slot="{ Component }">
        <transition mode="out-in" name="el-fade-in-linear">
          <component :is="Component"/>
        </transition>
      </router-view>

    </div>

  </div>
</template>

<script setup>
import {ref} from 'vue'

const imgUrl = ref("https://s2.loli.net/2024/03/18/n8bUNH3FcoZdzls.png")
</script>

<style scoped>
.welcome-foot {
  position: absolute;
  bottom: 2rem;
  left: 2rem;
  color: white;
  text-shadow: 1px 1px 2px #558ABB;
  user-select: none;
}
</style>