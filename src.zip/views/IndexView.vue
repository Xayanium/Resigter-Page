<template>
  <!--  <div>Welcome To Our Website: {{ store.auth.user.username }}</div>-->
  <!--  <el-button @click="logout" type="danger">Log out</el-button>-->

  <div class="common-layout">
    <el-container style="height: 100%">
      <div class="aside">
        <common-aside/>
      </div>
      <el-container>
        <el-header>
          <HomeHeader/>
        </el-header>
        <el-container>
          <router-view/>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import CommonAside from "../components/homepage/CommonAside.vue";
import HomeHeader from "../layout/HomeHeader.vue";
import {ref} from 'vue'

const imgUrl = ref("https://s2.loli.net/2024/03/19/KXEYyrMbOGBacpq.png")
</script>

<style scoped>
html,
body,
#app,
.common-layout,
.el-container {
  margin: 0;
  padding: 0;
  height: 100%;
}

.el-main {
  background-color: #dbe1e7;
  //background: linear-gradient(#bce1ee, #98abce);
  color: #333;
  //text-align: center;
  //line-height: 160px;
}

.el-aside {
  margin-top: 3.77rem;
  background-color: #D3DCE6;
  color: #333;
  text-align: center;
  line-height: 200px;
}

.aside {
  background-color: #555c63;
}

.index-font {
  //position: absolute;
  bottom: 2rem;
  left: 2rem;
  color: white;
  text-shadow: 1px 1px 2px #558ABB;
  user-select: none;
}
</style>