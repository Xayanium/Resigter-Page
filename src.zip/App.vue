<template>
  <router-view/>
</template>

<script setup>
import {get} from "./utils/axios.js";
import {useStore} from "../src/store"
import router from "./router/index.js";

const store = useStore()
if (store.auth.user == null) {
  get('/api/user/me', (message) => {
    // store.auth.user = message
    // router.push('/index')
  }, () => {
    // store.auth.user = null
  })
}


</script>

<style>
html, body, #app {
  margin: 0;
  padding: 0;
  height: 100%;
}
</style>
