// import {createPinia} from 'pinia'
//
// const store = createPinia()

import {defineStore} from 'pinia'
import {reactive} from "vue";

export const useStore = defineStore('store', () => {
    const auth = reactive({
        user: null
    })
    return {auth}
})


// export default store