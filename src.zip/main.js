import {createApp} from 'vue'
import App from './App.vue'
// import store from './store'
import {createPinia} from "pinia";
import router from './router';
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import axios from "axios";


// 创建vue实例
const app = createApp(App)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component)
}

axios.defaults.baseURL = 'http://192.168.101.25:8080';
axios.defaults.withCredentials = true;

// 挂载pinia和vue-router
const pinia = createPinia()
app.use(router).use(pinia)

// 挂载实例
app.mount('#app');

