<template>
  <div style="text-align: center;margin: 0 3rem">
    <div style="margin-top: 12rem">
      <div style="font-size: 3rem">Register</div>
      <div style="margin-top: 1rem;font-size: 1rem;color:grey;">Welcome to our platform</div>
    </div>

    <div style="margin-top: 3rem">
      <el-form :model="form" :rules="rules" @validate="onValidate" ref="formRef">
        <el-form-item prop="username">
          <el-input v-model="form.username" type="text" placeholder="username">
            <template #prefix>
              <el-icon>
                <User/>
              </el-icon>
            </template>
          </el-input>
        </el-form-item>

        <el-form-item prop="password">
          <el-input v-model="form.password" :type="passFlag ? 'text' : 'password'" placeholder="password">
            <template #prefix>
              <el-icon>
                <Lock/>
              </el-icon>
            </template>
            <template #suffix>
          <span @click="passFlag=!passFlag" style="cursor: pointer">
            <el-icon v-if="passFlag"><View/></el-icon>
            <el-icon v-else><Hide/></el-icon>
          </span>
            </template>
          </el-input>
        </el-form-item>

        <el-form-item prop="re_password">
          <el-input v-model="form.re_password" :type="addPassFlag ? 'text' : 'password'" placeholder="repeat password">
            <template #prefix>
              <el-icon>
                <Lock/>
              </el-icon>
            </template>
            <template #suffix>
          <span @click="addPassFlag=!addPassFlag" style="cursor: pointer">
            <el-icon v-if="addPassFlag"><View/></el-icon>
            <el-icon v-else><Hide/></el-icon>
          </span>
            </template>
          </el-input>
        </el-form-item>

        <el-form-item prop="email">
          <el-input v-model="form.email" type="text" placeholder="email address">
            <template #prefix>
              <el-icon>
                <Message/>
              </el-icon>
            </template>
          </el-input>
        </el-form-item>

        <el-form-item prop="code">
          <el-row :gutter="10" style="width: 100%">
            <el-col :span="16">
              <el-input v-model="form.code" type="text" placeholder="verify code">
                <template #prefix>
                  <el-icon>
                    <EditPen/>
                  </el-icon>
                </template>
              </el-input>
            </el-col>
            <el-col :span="8" style="text-align: right">
              <el-button @click="validateEmail" :disabled="!isEmailValid||coldTime>0"
                         type="success" style="text-align: right"
                         plain>
                {{ coldTime > 0 ? 'Please wait ' + coldTime + ' seconds' : 'Get Verify Code' }}
              </el-button>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>

    </div>

    <div style="margin-top: 2rem; text-align: center">
      <el-button @click="register" type="warning" style="width: 15rem" plain>Register</el-button>
    </div>

    <div style="font-size: 1rem; margin-top: 1rem">
      <el-link type="primary" @click="router.push('/')">Already Has Account?</el-link>
    </div>

  </div>

</template>

<script setup>
import {Hide, View} from "@element-plus/icons-vue";
import {reactive, ref} from "vue";
import router from "../../router/index.js";
import {ElMessage} from "element-plus";
import {post} from "../../utils/axios.js";

//眼睛效果
const passFlag = ref(false)
const addPassFlag = ref(false)

//表单
const form = reactive({
  username: '',
  password: '',
  re_password: '',
  email: '',
  code: ''
})


//表单校验
const validateUsername = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('Please input the username'))
  } else if (!/^[a-zA-Z0-9\u4e00-\u9fa5]+$/.test(value)) {
    callback(new Error('username ONLY can use a~z'))
  } else {
    callback()
  }
}

const validatePass2 = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('Please input the password again'))
  } else if (value !== form.password) {
    callback(new Error("Two inputs don't match!"))
  } else {
    callback()
  }
}

const rules = {
  username: [
    {validator: validateUsername, trigger: ['blur', 'change']},
    {min: 2, max: 8, message: 'Length should be 3 to 5', trigger: ['blur', 'change']},
  ],
  password: [
    {
      min: 6, max: 16, required: true,
      message: 'Length should be 3 to 50', trigger: ['blur', 'change']
    }
  ],
  re_password: [
    {validator: validatePass2, trigger: ['blur', 'change']},
  ],
  email: [
    {
      type: 'email', required: true,
      message: 'Please input correct email address',
      trigger: ['blur', 'change'],
    },
  ],
  code: [
    {required: true, message: 'Please input verify code'}
  ]
}

//验证邮箱是否合法
const isEmailValid = ref(false)
const onValidate = (prop, isValid) => {
  if (prop === 'email')
    isEmailValid.value = isValid
}

const formRef = ref()
const register = () => {
  formRef.value.validate((isValid) => {
    if (isValid) {
      post('/api/auth/register', {
        username: form.username,
        password: form.password,
        email: form.email,
        code: form.code
      }, (message) => {
        ElMessage.success(message)
        router.push('/')
      })
    } else {
      ElMessage.warning("Please input information correctly!")
    }
  })
}

//发送验证码后的等待时间
const coldTime = ref(0)


//邮件发送
const validateEmail = () => {
  coldTime.value = 60
  post('/api/auth/valid-register-email', {
    email: form.email
  }, (message) => {
    ElMessage.success(message)
    setInterval(() => coldTime.value--, 1000)
  }, (message) => {
    ElMessage.warning(message)
    coldTime.value = 0
  })
}

</script>

<style scoped>

</style>