<template>
  <div style="text-align: center;margin: 0 3rem">
    <div style="margin-top: 12rem">
      <div style="font-size: 3rem">Log In</div>
      <div style="margin-top: 1rem;font-size: 1rem;color:grey;">please sign up before you enter this system</div>
    </div>

    <div style="margin-top: 3rem;">
      <el-input v-model="form.username" type="text" placeholder="username/email" input-style="font-size: 1.2rem; ">
        <template #prefix>
          <el-icon>
            <User/>
          </el-icon>
        </template>
      </el-input>
      <el-input v-model="form.password" :type="addPassFlag ? 'text' : 'password'" placeholder="password"
                style="margin-top: 1rem"
                input-style="font-size: 1.2rem;">
        <template #prefix>
          <el-icon>
            <Lock/>
          </el-icon>
        </template>
        <template #suffix>
          <span @click="addPassFlag=!addPassFlag" style="cursor: pointer">
            <el-icon v-if="addPassFlag"><View/></el-icon>
            <el-icon v-else><Hide/></el-icon>
          </span>
        </template>
      </el-input>

      <el-row>
        <el-col :span="12" style="text-align: left; margin-top: 0.3rem">
          <el-checkbox v-model="form.remember" label="Remember Me" size="large"/>
        </el-col>
        <el-col :span="12" style="text-align: right; margin-top: 0.6rem;">
          <el-link @click="router.push('/forget')">Forget Password?</el-link>
        </el-col>
      </el-row>
    </div>


    <div style="margin-top: 2.3rem">
      <el-button @click="login" style="width: 12rem;height: 2.5rem" type="primary" plain>Log in</el-button>
    </div>
    <el-divider>
      <span style="color:grey; font-size: 15px">No account?</span>
    </el-divider>
    <div style="margin-top: 2.3rem">
      <el-button @click="router.push('/register')" style="width: 12rem;height: 2.5rem" type="success" plain>Register
      </el-button>
    </div>

  </div>
</template>

<script setup>
import {reactive, ref} from "vue";
import router from "../../router/index.js";
import {ElMessage} from "element-plus";
import {get, post} from "../../utils/axios.js";
import {View, Hide} from "@element-plus/icons-vue";
import {useStore} from "../../store/index.js";

const form = reactive({
  username: '',
  password: '',
  remember: false,
})

const addPassFlag = ref(false)

const store = useStore()

const login = () => {
  if (!form.username || !form.password) {
    ElMessage.warning("Please input username and password")
  } else {
    post('/api/auth/login', {
      username: form.username,
      password: form.password,
      remember: form.remember,
    }, (message) => {
      ElMessage.success(message)
      router.push('/index')
      // get('/api/user/me', (message) => {
      //   console.log(message)
      //   store.auth.user = message
      //   router.push('/index')
      // }, () => {
      //   store.auth.user = null
      // })
    })
  }
}


</script>

<style scoped>

</style>