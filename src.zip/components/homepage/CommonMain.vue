<template>
  <el-main>
    <!-- 面包屑 -->
    <!--    <el-breadcrumb separator="/">-->
    <!--      <el-breadcrumb-item :to="{ path: '/' }">home</el-breadcrumb-item>-->
    <!--      <el-breadcrumb-item>student information</el-breadcrumb-item>-->
    <!--    </el-breadcrumb>-->
    <el-breadcrumb :separator-icon="ArrowRight">
      <el-breadcrumb-item :to="{ path: '/' }">homepage</el-breadcrumb-item>
      <el-breadcrumb-item>promotion management</el-breadcrumb-item>
      <el-breadcrumb-item>promotion list</el-breadcrumb-item>
      <el-breadcrumb-item>promotion detail</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 搜索栏 -->
    <el-form :inline="true" style="margin-top:20px">
      <el-row :gutter="1">
        <el-col :span="10">
          <div class="grid-content ep-bg-purple"/>
          <el-form-item label="请输入查询条件:">
            <el-input v-model="inputStr" placeholder="请输入查询条件" style="width: 320px"
                      @keyup.enter.native="queryStudents"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <div class="grid-content ep-bg-purple"/>
          <el-button type="primary" :icon="Search" @click="queryStudents()">
            查询
          </el-button>
          <el-button type="primary" :icon="Tickets">
            显示
          </el-button>
          <el-button type="primary" :icon="CirclePlusFilled" @click="addStudents()">
            添加
          </el-button>
        </el-col>
        <el-col :span="2">
          <div class="grid-content ep-bg-purple"/>
          <el-upload>
            <el-button type="primary">
              导入Excel
            </el-button>
          </el-upload>
        </el-col>
        <el-col :span="2">
          <div class="grid-content ep-bg-purple"/>
          <el-upload>
            <el-button type="primary">
              导出Excel
            </el-button>
          </el-upload>
        </el-col>
      </el-row>
    </el-form>

    <!-- 表格 -->
    <el-table @selection-change="handleSelectionChange" :data="pageStudents" border style="width: 100%">
      <el-table-column type="selection" width="40" align="center"/>
      <el-table-column type="index" label="序号" width="60" align="center"/>
      <el-table-column prop="sno" label="学号" width="60" align="center"/>
      <el-table-column prop="name" label="姓名" width="150" align="center"/>
      <el-table-column prop="gender" label="性别" width="60" align="center"/>
      <el-table-column prop="birthday" label="出生日期" width="120" align="center"/>
      <el-table-column prop="mobile" label="电话" width="120" align="center"/>
      <el-table-column prop="email" label="邮箱" width="240" align="center"/>
      <el-table-column prop="address" label="地址" width="160" align="center"/>
      <el-table-column label="操作" width="200" size="mini" align="center">
        <template #default="scope">
          <el-button type="success" :icon="More" circle @click="viewStudents(scope.row)"/>
          <el-button type="primary" :icon="Edit" circle @click="updateStudents(scope.row)"/>
          <el-button type="danger" :icon="Delete" circle @click="submitDeleteStudents(scope.row)"/>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <el-row style="margin-top: 10px;">
      <el-col :span="8" style="text-align: left;">
        <el-button @click="deleteStudents()" type="danger">批量删除</el-button>
      </el-col>
      <el-col :span="8" style="text-align: right;">
        <div class="demo-pagination-block">
          <el-pagination
              v-model:current-page="currentPage"
              v-model:pagesize="pageSize"
              :page-sizes="[5, 10, 20, 50]"
              :small="false"
              :disabled="false"
              :background="false"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
          />
        </div>
      </el-col>
    </el-row>

    <!-- 弹出框 -->
    <el-dialog :title="dialogTitle" v-model="dialogVisible" width=55% @close="closeDialogForm(studentForm)">
      <el-form ref="formRef" :model="studentForm" :rules="rules" :inline="true" style="margin-left: 30px;"
               label-width="80px">
        <el-form-item label="学号:" prop="sno">
          <el-input v-model="studentForm.sno" :suffix-icon="EditPen"></el-input>
        </el-form-item>
        <el-form-item label="姓名:" prop="name">
          <el-input v-model="studentForm.name" :suffix-icon="EditPen"></el-input>
        </el-form-item>
        <el-form-item label="性别:">
          <el-select v-model="studentForm.gender" placeholder="请选择性别">
            <el-option label="男" value="男"></el-option>
            <el-option label="女" value="男"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="出生日期:" prop="birthday">
          <el-date-picker format="YYYY/MM/DD" value-format="YYYY-MM-DD" v-model="studentForm.birthday" type="date"
                          placeholder="选择日期" style="width: 100%"/>
        </el-form-item>
        <el-form-item label="手机号码:">
          <el-input v-model="studentForm.mobile" :suffix-icon="EditPen"></el-input>
        </el-form-item>
        <el-form-item label="邮箱地址:">
          <el-input v-model="studentForm.email" :suffix-icon="EditPen"></el-input>
        </el-form-item>
        <el-form-item label="家庭地址">
          <el-input v-model="studentForm.address" :suffix-icon="EditPen" style="width: 541px;"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
          <span class="dialog-footer">
            <el-button type="primary" v-show="!isView" @click="submitStudentForm()">提交</el-button>
            <el-button type="info" @click="closeDialogForm()">取消</el-button>
          </span>
      </template>
    </el-dialog>

  </el-main>
</template>

<script setup>
import {ref, reactive, toRaw, unref} from 'vue'
import {onMounted} from 'vue';
import axios from 'axios'
import {ElMessage} from 'element-plus'
import {ElMessageBox} from 'element-plus'
import "element-plus/theme-chalk/el-message.css";
import "element-plus/theme-chalk/el-message-box.css";
import "element-plus/theme-chalk/el-loading.css";
import "element-plus/theme-chalk/el-notification.css";
import {
  Check,
  Delete,
  Edit,
  Search,
  CirclePlusFilled,
  Tickets,
  EditPen,
  More,
} from '@element-plus/icons-vue'
import {ArrowRight} from '@element-plus/icons-vue'


const baseUrl = ref("http://192.168.101.16:8000/");


let Students = reactive([]); //所有学生的信息
onMounted(() => {
  axios.get(baseUrl.value + 'students/')
      .then(res => {
        if (res.data.code === 1) {
          const data = res.data.data;
          Students.push(...data);
          total.value = data.length; //更新总数据量
          getPageStudents();
          ElMessage({
            message: "数据加载成功!",
            type: 'success',
          });
        } else {
          ElMessage.error(res.data.msg);
        }
      })
      .catch(err => {
        console.log(err);
      })
});

let pageStudents = reactive([]); //分页后当前页的学生
//分页相关的变量
const total = ref(80); //数据总行数
const currentPage = ref(1); //当前所在的页
const pageSize = ref(10); //每页显示多少行
const inputStr = ref(""); //axios请求得到的数据
const dialogVisible = ref(false); //弹出框的是否可见
const dialogTitle = ref("") //弹出框标题名字
const isView = ref(false);
const isUpdate = ref(false);
const studentForm = reactive({
  sno: "",
  name: "",
  gender: "",
  birthday: "",
  mobile: "",
  email: "",
  address: ""
})
const formRef = ref(null); //表单验证重置
const selectStudents = reactive([]) //记录选择了的复选框

const getPageStudents = () => { //获取当前页的学生数据
  pageStudents.length = 0; //每次获取都将数组清空
  for (let i = (currentPage.value - 1) * pageSize.value; i < total.value; i++) {
    //toRow可以将一个Proxy代理对象转换成普通对象
    const student = toRaw(Students[i]);
    //用以下方式也可
    //const student = JSON.parse(JSON.stringify(Students[i]))

    pageStudents.push(student); //将数据加入显示数组中

    if (pageStudents.length === pageSize.value) break; //判断是否达到分页的最大数据量
  }
}

//修改分页每页行数
const handleSizeChange = (size) => {
  pageSize.value = size;
  getPageStudents(); //重新加载学生信息
}

//修改当前页码
const handleCurrentChange = (demo) => {
  currentPage.value = demo;
  getPageStudents();
}

//实现学生信息查询
const queryStudents = () => {
  //使用axios请求--POST->传递inputStr
  axios.post(
      baseUrl.value + 'students/query/',
      {
        //和后端大小写保持一致
        inputstr: inputStr.value,
      },
  ).then(
      res => {
        if (res.data.code === 1) {
          Students.length = 0;
          const data = res.data.data;
          Students.push(...data);
          total.value = data.length;
          getPageStudents();
          ElMessage({
            message: "查询数据加载成功!",
            type: 'success',
          });
        } else {
          ElMessage.error(res.data.msg);
        }
      }
  ).catch(err => {
    console.log(err);
    ElMessage.error("获取后端数据异常:");
  })
}

//关闭弹出框
const closeDialogForm = () => {
  Object.assign(studentForm, {
    sno: "",
    name: "",
    gender: "",
    birthday: "",
    mobile: "",
    email: "",
    address: ""
  })
  dialogVisible.value = false;
  isView.value = false;
  isUpdate.value = false;
  //重置表单校验信息
  resetForm();
}

//查看学生信息的弹出框
const viewStudents = (row) => {
  dialogVisible.value = true;
  isView.value = true;
  dialogTitle.value = "查看学生信息"
  //JSON.parse() 用来解析JSON字符串，得到对应的JavaScript值或对象。
  //JSON.stringify() 将一个JavaScript对象或值转换为JSON格式字符串。
  //const data = JSON.parse(JSON.stringify(row))
  const data = toRaw(row);
  //对reactive对象赋值且不丢失响应式
  Object.assign(studentForm, data);
}

//添加学生时的弹出框
const addStudents = () => {
  dialogTitle.value = "添加学生信息"
  dialogVisible.value = true;
}

//修改学生时的弹出框
const updateStudents = (row) => {
  dialogTitle.value = "修改学生信息"
  dialogVisible.value = true;
  isUpdate.value = true;
  const data = toRaw(row);
  Object.assign(studentForm, data);
}


//添加更新到数据库
const submitAddStudents = () => {
  axios.post(baseUrl.value + 'students/add/', studentForm)
      .then(res => {
        //实时更新页面信息
        if (res.data.code === 1) {
          const data = res.data.data;
          Students.length = 0;
          Students.push(...data);
          total.value = data.length;
          getPageStudents();
          ElMessage({
            message: "数据添加成功!",
            type: 'success',
          });
          //自动关闭窗体
          closeDialogForm();
        } else {
          ElMessage.error(res.data.msg)
        }
      })
      .catch(err => {
        ElMessage.error("获取后端数据异常")
      })
}

//修改更新到数据库
const submitUpdateStudents = () => {
  axios.post(baseUrl.value + 'students/update/', studentForm)
      .then(res => {
        if (res.data.code === 1) {
          const data = res.data.data;
          Students.length = 0;
          Students.push(...data);
          total.value = data.length;
          getPageStudents();
          ElMessage({
            message: "数据修改成功!",
            type: 'success',
          });
          //自动关闭窗体
          closeDialogForm();
        } else {
          ElMessage.error(res.data.msg)
        }
      })
      .catch(err => {
        ElMessage.error("获取后端数据异常")
      })
}

//删除更新到数据库
const submitDeleteStudents = (row) => {
  const data = toRaw(row);
  console.log(data)
  //等待确认
  ElMessageBox.confirm(
      "是否确认删除学生 " + data.name,
      '警告',
      {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning',
      }
  ).then(() => {
    axios.post(baseUrl.value + 'students/delete/', {sno: data.sno})
        .then(res => {
          //实时更新页面信息
          if (res.data.code === 1) {
            //获取所有学生信息
            const students = res.data.data;
            Students.length = 0;
            Students.push(...students);
            //获取记录数
            total.value = students.length;
            //分页展示
            getPageStudents();
            //提示信息
            ElMessage({
              type: 'success',
              message: '删除学生成功',
            })
          } else {
            ElMessage.error(res.data.msg)
          }
        })
        .catch(err => {
          ElMessage.error("获取后端数据异常")
        })
  })
}

//表单验证学号
const ruleSNO = (rules, value, callback) => {
  if (isUpdate) callback();
  //使用axios进行校验
  axios.post(baseUrl.value + 'students/check/', {sno: value})
      .then(res => {
        if (res.data.code === 1) {
          if (res.data.exists) {
            callback(new Error("学号已存在"))
          } else {
            callback();
          }
        } else {
          callback(new Error("后端出现异常"))
        }
      })
      .catch(err => {
        console.log(err);
      })

}
//表单验证重置
const resetForm = () => {
  formRef.value.resetFields();
}

//提交学生的表单(添加, 修改)
const submitStudentForm = async () => {
  const form = unref(formRef)
  if (!form) return;
  await form.validate((valid) => {
    if (valid) {
      if (isUpdate.value) {
        submitUpdateStudents();
      } else {
        submitAddStudents();
      }
    } else {
      return false;
    }
  })
}

//批量删除钩子函数
const handleSelectionChange = (data) => {
  //传递过来的data是一个proxy数组,需要转为js数组
  const newData = JSON.parse(JSON.stringify(data))
  selectStudents.length = 0;
  //push的时候需要解构
  selectStudents.push(...newData);
}

//批量删除
const deleteStudents = () => {
  const data = JSON.parse(JSON.stringify(selectStudents))
  //等待确认
  ElMessageBox.confirm(
      "是否确认批量删除 ",
      '警告',
      {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        type: 'warning',
      }
  ).then(() => {
    axios.post(baseUrl.value + 'students/sum_delete/', {students: data})
        .then(res => {
          //实时更新页面信息
          if (res.data.code === 1) {
            console.log(res.data.data)
            //获取所有学生信息
            const students = res.data.data;
            Students.length = 0;
            Students.push(...students);
            //获取记录数
            total.value = students.length;
            //分页展示
            getPageStudents();
            //提示信息
            ElMessage({
              type: 'success',
              message: '批量删除学生成功',
            })
          } else {
            ElMessage.error(res.data.msg)
          }
        })
        .catch(err => {
          ElMessage.error("获取后端数据异常")
        })
  })
}


const rules = reactive({
  sno: [
    {required: true, message: "学号不能为空", trigger: "blur"},
    {validator: ruleSNO, trigger: "blur"},

  ],
  name: [
    {required: true, message: "姓名不能为空", trigger: "blur"}
  ],
  birthday: [
    {required: true, message: "请选择出生日期", trigger: "blur"}
  ]
})
</script>

<style scoped>
</style>