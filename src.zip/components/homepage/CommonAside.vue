<template>
  <el-aside width="15rem">
    <el-menu
        active-text-color="#ffd04b"
        background-color="#545c64"
        class="el-menu-vertical-demo"
        default-active="2"
        text-color="#fff"
        :router="true">
      <el-menu-item index="/index/class">
        <el-icon>
          <House/>
        </el-icon>
        <span>班级管理</span>
      </el-menu-item>
      <el-menu-item index="/index/student">
        <el-icon>
          <User/>
        </el-icon>
        <span>学生信息</span>
      </el-menu-item>
      <el-menu-item index="/index/teacher">
        <el-icon>
          <Avatar/>
        </el-icon>
        <span>教师信息</span>
      </el-menu-item>
      <el-menu-item index="/index/course">
        <el-icon>
          <Tickets/>
        </el-icon>
        <span>课程管理</span>
      </el-menu-item>
      <el-menu-item index="/index/user">
        <el-icon>
          <Menu/>
        </el-icon>
        <span>个人信息</span>
      </el-menu-item>
    </el-menu>
  </el-aside>
</template>

<script setup>

</script>

<style scoped>

</style>