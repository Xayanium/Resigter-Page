<template>
  <div>

    <el-image :src="imgUlr" style="width: 100%;height: 100%" fit="cover"></el-image>
  </div>

</template>

<script setup>
import {ref} from 'vue'

const imgUlr = ref("https://s2.loli.net/2024/03/19/KXEYyrMbOGBacpq.png")
</script>

<style scoped>

</style>