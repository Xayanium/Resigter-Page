<template>
  <el-image :src="crsUlr" style="width: 100%;height: 100%" fit="cover"></el-image>
</template>

<script setup>
import {ref} from 'vue'

const crsUlr = ref("https://s2.loli.net/2024/03/18/EJitzFqISAnh538.jpg")
</script>

<style scoped>

</style>