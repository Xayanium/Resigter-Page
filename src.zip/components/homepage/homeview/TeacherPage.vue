<template>
  <el-image :src="imgUrl" style="width: 100%;height: 100%" fit="cover"></el-image>
</template>

<script setup>
import {ref} from 'vue'

const imgUrl = ref("https://s2.loli.net/2024/03/18/1pnE6giSwFTUmsd.png")
</script>

<style scoped>

</style>