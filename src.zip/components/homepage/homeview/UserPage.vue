<template>
  <el-image :src="userUrl" style="width: 100%;height: 100%" fit="cover"></el-image>
</template>

<script setup>
import {ref} from 'vue'

const userUrl = ref("https://s2.loli.net/2024/03/18/oaCjRZWgr8Px4we.jpg ")
</script>

<style scoped>

</style>