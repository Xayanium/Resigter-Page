<template>
  <el-image :src="clsUlr" style="width: 100%;height: 100%" fit="cover"></el-image>
</template>

<script setup>
import {ref} from 'vue'

const clsUlr = ref("https://s2.loli.net/2024/03/19/nuqt6D3FOaCjL4B.png")
</script>

<style scoped>

</style>