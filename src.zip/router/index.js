import {createRouter, createWebHistory} from 'vue-router';
import {useStore} from "../store";

const routes = [
    {
        path: '/',
        name: 'welcome',
        component: () => import('../views/WelcomeView.vue'),
        children: [
            {
                path: '',
                name: 'welcome-login',
                component: () => import('../components/welcome/LoginPage.vue')
            },
            {
                path: 'register',
                name: 'welcome-register',
                component: () => import('../components/welcome/RegisterPage.vue')
            },
            {
                path: 'forget',
                name: 'welcome-forget',
                component: () => import('../components/welcome/ForgetPage.vue')
            }
        ]
    },
    {
        path: '/index',
        name: 'index',
        component: () => import('../views/IndexView.vue'),
        children: [
            {
                path: '',
                name: 'index',
                component: () => import('../components/homepage/homeview/IndexPage.vue')
            },
            {
                path: 'user',
                name: 'index-user',
                component: () => import('../components/homepage/homeview/UserPage.vue')
            },
            {
                path: 'class',
                name: 'index-class',
                component: () => import('../components/homepage/homeview/ClassPage.vue')
            },
            {
                path: 'student',
                name: 'index-student',
                component: () => import('../components/homepage/homeview/StudentPage.vue')
            },
            {
                path: 'teacher',
                name: 'index-teacher',
                component: () => import('../components/homepage/homeview/TeacherPage.vue')
            },
            {
                path: 'course',
                name: 'index-course',
                component: () => import('../components/homepage/homeview/CoursePage.vue')
            }
        ]
    },

]

const router = createRouter({
    history: createWebHistory(),
    routes
});

// router.beforeEach((to, from, next) => {
//     const store = useStore()
//     if (store.auth.user != null && to.name.startsWith('welcome-')) {
//         next('index')
//     } else if (store.auth.user == null && to.fullPath.startsWith('/index')) {
//         next('/')
//     } else if (to.matched.length === 0) {
//         next('index')
//     } else {
//         next()
//     }
// })
export default router;
