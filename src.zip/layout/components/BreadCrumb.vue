<template>
  <el-breadcrumb :separator-icon="ArrowRight">
    <!--    <el-breadcrumb-item :to="{ path: '/' }">homepage</el-breadcrumb-item>-->
    <el-breadcrumb-item v-for="(item, index) in breadcrumbList" :key="index">
      <span class="no-redirect" v-if="index === breadcrumbList.length-1">{{ item.name }}</span>
      <span class="redirect" @click="handleRedirect(item.path)" v-else>{{ item.name }}</span>
    </el-breadcrumb-item>
  </el-breadcrumb>
</template>

<script setup>
import {useRoute, useRouter} from 'vue-router'
import {watch, ref} from 'vue'
import {ArrowRight} from "@element-plus/icons-vue";

const route = useRoute()
const router = useRouter()
const breadcrumbList = ref([])

const initBreadcrumbList = () => {
  breadcrumbList.value = route.matched
}

const handleRedirect = (path) => {
  router.push(path)
}

watch(route, () => {
  initBreadcrumbList()
}, {deep: true, immediate: true})
</script>

<style lang="scss" scoped>
.no-redirect {
  color: #97a8be;
  cursor: not-allowed;
}

.redirect {
  color: #666;
  cursor: pointer;
  font-weight: 600;

  &:hover {
    color: #304156;
  }
}
</style>