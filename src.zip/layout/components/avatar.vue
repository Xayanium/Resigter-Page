<template>
  <el-dropdown>
    <span class="el-dropdown-link">
      <el-avatar shape="square" :size="40" :src="squareUrl" style="cursor: pointer"></el-avatar>
    </span>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item @click="logout">Log Out</el-dropdown-item>
        <el-dropdown-item>More</el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>

</template>

<script setup>
import {ref} from 'vue'
import {get} from '../../utils/axios.js'
import {ElMessage} from "element-plus";
import router from "../../router/index.js";
import {useStore} from "../../store/index.js";

const squareUrl = ref("https://s2.loli.net/2024/03/18/KguPwDkX3Bp57Uc.jpg")


const store = useStore()
const logout = () => {
  get('api/auth/logout', (message) => {
    ElMessage.success(message)
    store.auth.user = null
    router.push('/')
  })
}
</script>

<style lang="scss" scoped>
::v-deep el-dropdown-menu__item {
  white-space: nowrap;
}
</style>